import { Component } from '@angular/core';

@Component({
  selector: 'angular',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title:string="ACCENTURE";
//BINDING THE DATA FROM MODEL TO VIEW <-->view to model
                        //TS TO HTML   BINDING EXPRESSION
}
